from django.shortcuts import render,redirect,get_object_or_404
from django.contrib.auth.forms import AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from .models import sif
# Create your views here.
@login_required
def home(request):
    data = sif.objects.all()
    return render(request, 'home.html', {'data': data})
def user_login(request):
    if request.method == 'POST':
        form = AuthenticationForm(data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('home')
    else:
        form = AuthenticationForm()
    return render(request, 'login.html', {'form': form})

def user_logout(request):
    logout(request)
    return redirect("login")

def form(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        enrollment = request.POST.get('enrollment')
        roll = request.POST.get('roll')
        dob = request.POST.get('dob')
        title = request.POST.get('title')
        sif.objects.create(name=name, enrollment=enrollment, roll=roll, dob=dob, title=title)
        return redirect('home')

    return render(request, 'form.html')

def update(request, id):

    d = get_object_or_404(sif,
        id=id
    )

    if request.method == 'POST':

        d.name = request.POST.get('name')
        d.enrollment = request.POST.get('enrollment')
        d.roll = request.POST.get('roll')
        d.dob = request.POST.get('dob')
        d.title = request.POST.get('title')

        d.save()

        return redirect('home')

    return render(
        request,
        'update.html',
        {'data': d}
    )

def delete(req,id):
    d=get_object_or_404(sif,id=id)
    d.delete()
    return redirect("home")
from datetime import datetime  # <-- Make sure to add this import at the top of views.py

def upload_csv(request):
    if request.method == 'POST':
        if 'csv_file' not in request.FILES:
            return render(request, 'upload_csv.html', {'error': 'No file was uploaded'})
            
        csv_file = request.FILES['csv_file']
        if not csv_file.name.endswith('.csv'):
            return render(request, 'upload_csv.html', {'error': 'File is not CSV type'})
            
        # Process the CSV file and save data to the database
        import csv
        from io import TextIOWrapper

        file_data = TextIOWrapper(csv_file.file, encoding='utf-8')
        reader = csv.DictReader(file_data)
        
        for row in reader:
            # Get the date string from the CSV row
            date_str = row['dob'].strip()
            
            try:
                # Parse DD-MM-YYYY format and convert it to YYYY-MM-DD
                parsed_date = datetime.strptime(date_str, '%d-%m-%Y').date()
            except ValueError:
                # Fallback check: if the date is already in YYYY-MM-DD format, parse it properly
                try:
                    parsed_date = datetime.strptime(date_str, '%Y-%m-%d').date()
                except ValueError:
                    return render(request, 'upload_csv.html', {
                        'error': f"Invalid date format for '{date_str}'. Use DD-MM-YYYY or YYYY-MM-DD."
                    })

            sif.objects.create(
                name=row['name'],
                enrollment=row['enrollment'],
                roll=row['roll'],
                dob=parsed_date,  # <-- Pass the corrected datetime object here
                title=row['title']
            )
        return redirect('home')
        
    return render(request, 'upload_csv.html')
