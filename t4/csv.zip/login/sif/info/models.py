from django.db import models

# Create your models here.
class sif(models.Model):
    name = models.CharField()
    enrollment = models.CharField()
    roll = models.IntegerField()
    dob = models.DateField()
    title = models.CharField()

    def __str__(self):
        return self.name
