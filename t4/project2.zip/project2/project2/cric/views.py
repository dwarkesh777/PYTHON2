from django.shortcuts import render
import requests
import os
os.environ['NO_PROXY'] = '127.0.0.1,localhost'

# Create your views here.

def home(request):
    url="http://localhost:8000/api/cricket/"
    data=requests.get(url)
    data=data.json()

    return render(request,'home.html',{'data':data})

def delete(request,id):
    url="http://localhost:8000/api/cricket/"+str(id)+"/"
    data=requests.delete(url)
    return render(request,'home.html',{'data':data})

def update(request,id):
    url="http://localhost:8000/api/cricket/"+str(id)+"/"
    # d=get_object_or_404(Cricket,id=id)
    return render(request,'home.html',{'data':data})