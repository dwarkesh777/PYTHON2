from django.shortcuts import render
from django.http import HttpResponse
from openpyxl import Workbook
from .models import data
# Create your views here.
def home(request):
    d=data.objects.all()
    return render(request, 'home.html', {'data': d})

def download_excel(request):
    wb = Workbook()
    ws = wb.active
    ws.title = "Data"

    ws.append(['Name', 'Email', 'Phone', 'Address'])

    d=data.objects.all()
    for item in d:
        ws.append([item.name, item.email, item.phone, item.address])

    response = HttpResponse(content_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
    response['Content-Disposition'] = 'attachment; filename="data.xlsx"'
    wb.save(response)
    return response