from django.db import models

# Create your models here.
class data(models.Model):
    name = models.CharField()
    email = models.EmailField()
    phone = models.CharField()
    address = models.TextField()

    def __str__(self):
        return self.name