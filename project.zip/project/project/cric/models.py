from django.db import models

# Create your models here.

class cricket(models.Model):
    team_name= models.CharField()
    player_name= models.CharField()
    runs= models.IntegerField()
    centrury= models.IntegerField()
    debut_date=models.DateField()
    email_id=models.EmailField()

    def __str__(self):
        return self.team_name