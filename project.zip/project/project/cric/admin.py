from django.contrib import admin
from .models import cricket
# Register your models here.
admin.site.register(cricket)