from django.shortcuts import render
from rest_framework import viewsets

from .serializers import data_cricket
from .models import cricket
# Create your views here.
class cricket_view(viewsets.ModelViewSet):
    queryset=cricket.objects.all()
    serializer_class=data_cricket
