from rest_framework import serializers
from .models import cricket

class data_cricket(serializers.ModelSerializer):
    class Meta:
        model=cricket
        fields='__all__'
